# Loss and accuracy values for Fashion MNIST
fashion_mnist_loss = [2.0301, 0.9366, 0.8966, 0.8802, 0.8715, 0.8610, 0.8585, 0.8536, 0.8500, 0.8462]
fashion_mnist_accuracy = [0.6829, 0.7537, 0.7691, 0.7737, 0.7800, 0.7832, 0.7845, 0.7887, 0.7874, 0.7896]

# Loss and accuracy values for validation set of Fashion MNIST
fashion_mnist_val_loss = [0.8911, 0.8302, 0.8630, 0.7904, 0.7983, 0.7626, 0.8057, 0.7874, 0.7539, 0.7928]
fashion_mnist_val_accuracy = [0.7760, 0.7878, 0.7765, 0.8046, 0.8064, 0.8190, 0.8061, 0.8019, 0.8163, 0.8059]

fashion_mnist_classification_report = {
    "0": {"precision": 0.73, "recall": 0.84, "f1-score": 0.78, "support": 1394},
    "1": {"precision": 1.00, "recall": 0.92, "f1-score": 0.96, "support": 1402},
    "2": {"precision": 0.79, "recall": 0.73, "f1-score": 0.76, "support": 1407},
    "3": {"precision": 0.74, "recall": 0.92, "f1-score": 0.82, "support": 1449},
    "4": {"precision": 0.74, "recall": 0.65, "f1-score": 0.69, "support": 1357},
    "5": {"precision": 0.98, "recall": 0.73, "f1-score": 0.84, "support": 1449},
    "6": {"precision": 0.57, "recall": 0.47, "f1-score": 0.51, "support": 1407},
    "7": {"precision": 0.73, "recall": 0.93, "f1-score": 0.82, "support": 1359},
    "8": {"precision": 0.93, "recall": 0.95, "f1-score": 0.94, "support": 1342},
    "9": {"precision": 0.90, "recall": 0.92, "f1-score": 0.91, "support": 1434},
    "accuracy": 0.81,
    "macro avg": {"precision": 0.81, "recall": 0.81, "f1-score": 0.80, "support": 14000},
    "weighted avg": {"precision": 0.81, "recall": 0.81, "f1-score": 0.80, "support": 14000}
}

fashion_mnist_confusion_matrix = [
    [1174, 0, 24, 113, 8, 3, 50, 0, 21, 1],
    [4, 1288, 1, 93, 2, 1, 10, 0, 3, 0],
    [23, 0, 1030, 60, 147, 0, 120, 5, 22, 0],
    [33, 2, 21, 1333, 31, 1, 24, 1, 3, 0],
    [4, 0, 80, 104, 887, 0, 272, 0, 10, 0],
    [1, 1, 0, 9, 0, 1057, 0, 329, 3, 49],
    [354, 2, 147, 81, 125, 2, 656, 0, 39, 1],
    [0, 0, 0, 0, 0, 3, 0, 1269, 1, 86],
    [5, 0, 3, 13, 3, 5, 20, 21, 1270, 2],
    [0, 0, 0, 6, 0, 4, 1, 104, 0, 1319]
]

import matplotlib.pyplot as plt
import numpy as np

# Number of epochs
epochs = range(1, 11)

# Create subplots for loss and accuracy
plt.figure(figsize=(12, 6))

# Plot training and validation loss
plt.subplot(1, 2, 1)
plt.plot(epochs, fashion_mnist_loss, 'b-', label='Training Loss')
plt.plot(epochs, fashion_mnist_val_loss, 'r-', label='Validation Loss')
plt.title('Fashion MNIST Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# Plot training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(epochs, fashion_mnist_accuracy, 'b-', label='Training Accuracy')
plt.plot(epochs, fashion_mnist_val_accuracy, 'r-', label='Validation Accuracy')
plt.title('Fashion MNIST Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.tight_layout()

# Bar plot for F1-scores
f1_scores = [fashion_mnist_classification_report[str(i)]['f1-score'] for i in range(10)]
class_labels = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot"
]


plt.figure(figsize=(8, 6))
plt.bar(class_labels, f1_scores, color='royalblue')
plt.title('Fashion MNIST F1-Scores')
plt.xlabel('Class Labels')
plt.ylabel('F1-Score')
plt.ylim([0, 1])
plt.xticks(rotation=45)
plt.show()

# Loss and accuracy values for Fashion MNIST
fashion_mnist_loss = [2.0301, 0.9366, 0.8966, 0.8802, 0.8715, 0.8610, 0.8585, 0.8536, 0.8500, 0.8462]
fashion_mnist_accuracy = [0.6829, 0.7537, 0.7691, 0.7737, 0.7800, 0.7832, 0.7845, 0.7887, 0.7874, 0.7896]

# Loss and accuracy values for validation set of Fashion MNIST
fashion_mnist_val_loss = [0.8911, 0.8302, 0.8630, 0.7904, 0.7983, 0.7626, 0.8057, 0.7874, 0.7539, 0.7928]
fashion_mnist_val_accuracy = [0.7760, 0.7878, 0.7765, 0.8046, 0.8064, 0.8190, 0.8061, 0.8019, 0.8163, 0.8059]

fashion_mnist_classification_report = {
    "0": {"precision": 0.73, "recall": 0.84, "f1-score": 0.78, "support": 1394},
    "1": {"precision": 1.00, "recall": 0.92, "f1-score": 0.96, "support": 1402},
    "2": {"precision": 0.79, "recall": 0.73, "f1-score": 0.76, "support": 1407},
    "3": {"precision": 0.74, "recall": 0.92, "f1-score": 0.82, "support": 1449},
    "4": {"precision": 0.74, "recall": 0.65, "f1-score": 0.69, "support": 1357},
    "5": {"precision": 0.98, "recall": 0.73, "f1-score": 0.84, "support": 1449},
    "6": {"precision": 0.57, "recall": 0.47, "f1-score": 0.51, "support": 1407},
    "7": {"precision": 0.73, "recall": 0.93, "f1-score": 0.82, "support": 1359},
    "8": {"precision": 0.93, "recall": 0.95, "f1-score": 0.94, "support": 1342},
    "9": {"precision": 0.90, "recall": 0.92, "f1-score": 0.91, "support": 1434},
    "accuracy": 0.81,
    "macro avg": {"precision": 0.81, "recall": 0.81, "f1-score": 0.80, "support": 14000},
    "weighted avg": {"precision": 0.81, "recall": 0.81, "f1-score": 0.80, "support": 14000}
}

fashion_mnist_confusion_matrix = [
    [1174, 0, 24, 113, 8, 3, 50, 0, 21, 1],
    [4, 1288, 1, 93, 2, 1, 10, 0, 3, 0],
    [23, 0, 1030, 60, 147, 0, 120, 5, 22, 0],
    [33, 2, 21, 1333, 31, 1, 24, 1, 3, 0],
    [4, 0, 80, 104, 887, 0, 272, 0, 10, 0],
    [1, 1, 0, 9, 0, 1057, 0, 329, 3, 49],
    [354, 2, 147, 81, 125, 2, 656, 0, 39, 1],
    [0, 0, 0, 0, 0, 3, 0, 1269, 1, 86],
    [5, 0, 3, 13, 3, 5, 20, 21, 1270, 2],
    [0, 0, 0, 6, 0, 4, 1, 104, 0, 1319]
]

import matplotlib.pyplot as plt
import numpy as np

# Number of epochs
epochs = range(1, 11)

# Create subplots for loss and accuracy
plt.figure(figsize=(12, 6))

# Plot training and validation loss
plt.subplot(1, 2, 1)
plt.plot(epochs, fashion_mnist_loss, 'b-', label='Training Loss')
plt.plot(epochs, fashion_mnist_val_loss, 'r-', label='Validation Loss')
plt.title('Fashion MNIST Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# Plot training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(epochs, fashion_mnist_accuracy, 'b-', label='Training Accuracy')
plt.plot(epochs, fashion_mnist_val_accuracy, 'r-', label='Validation Accuracy')
plt.title('Fashion MNIST Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.tight_layout()

# Bar plot for F1-scores
f1_scores = [fashion_mnist_classification_report[str(i)]['f1-score'] for i in range(10)]
class_labels = [str(i) for i in range(10)]

plt.figure(figsize=(8, 6))
plt.bar(class_labels, f1_scores, color='royalblue')
plt.title('Fashion MNIST F1-Scores')
plt.xlabel('Class Labels')
plt.ylabel('F1-Score')
plt.ylim([0, 1])
plt.xticks(rotation=45)
plt.show()

import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import confusion_matrix
import seaborn as sns
class_labels = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot"
]
# Function to plot confusion matrix
def plot_confusion_matrix(cm, class_labels):
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_labels, yticklabels=class_labels)
    plt.title('Fashion MNIST Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()
class_labels = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot"
]
# Function to plot classification report
def plot_classification_report(report):
    class_labels = [
        "T-shirt/top",
        "Trouser",
        "Pullover",
        "Dress",
        "Coat",
        "Sandal",
        "Shirt",
        "Sneaker",
        "Bag",
        "Ankle boot"
    ]
    # Extract metrics and class labels
    metrics = ['precision', 'recall', 'f1-score', 'support']
    data = []
    for label, scores in report.items():
        if label.isdigit():
            data.append([float(scores[metric]) for metric in metrics])

    # Create an array to plot
    data_array = np.array(data)

    # Plot the classification report
    plt.figure(figsize=(10, 6))
    sns.heatmap(data_array, annot=True, cmap='Blues', xticklabels=metrics[:-1], yticklabels=class_labels)
    plt.title('Fashion MNIST Classification Report')
    plt.xlabel('Metrics')
    plt.ylabel('Class Labels')
    plt.show()

# Plot confusion matrix
confusion_matrix_data = np.array(fashion_mnist_confusion_matrix)
plot_confusion_matrix(confusion_matrix_data, class_labels)

# Plot classification report
plot_classification_report(fashion_mnist_classification_report)
