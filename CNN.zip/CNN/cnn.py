import pandas as pd
import numpy as np
from keras.datasets import fashion_mnist
from sklearn.preprocessing import scale
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D,Conv2D, MaxPooling1D,MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.regularizers import l2
from sklearn.metrics import classification_report, confusion_matrix

# Preprocessing functions
def preprocess_image_data(x):
    x = x.reshape(x.shape[0], -1)
    x = scale(x)
    x = x.reshape(-1, 28, 28, 1)
    return x

def preprocess_non_image_data(x):
    # Reshape data for 1D convolution
    x = x.reshape(x.shape[0], -1, 1)
    return x

# Load and preprocess Fashion-MNIST dataset
(train_X, train_y), (test_X, test_y) = fashion_mnist.load_data()
fashion_x = preprocess_image_data(np.concatenate((train_X, test_X), axis=0))
fashion_y = np.concatenate((train_y, test_y), axis=0)
fashion_train_x, fashion_val_x, fashion_train_y, fashion_val_y = train_test_split(fashion_x, fashion_y, test_size=0.2, random_state=42)

# Load and preprocess Blood Data
blood_data = pd.read_csv('blood_data (1).csv')
blood_x = preprocess_non_image_data(blood_data.iloc[:, :-1].to_numpy())
blood_y = blood_data.iloc[:, -1].to_numpy() - 1  # Subtract 1 from labels
blood_train_x, blood_val_x, blood_train_y, blood_val_y = train_test_split(blood_x, blood_y, test_size=0.2, random_state=42)

# Load and preprocess Satellite Data
sat_data = pd.read_csv('satellite_data.csv')
sat_x = preprocess_non_image_data(sat_data.iloc[:, :-1].to_numpy())
sat_y = sat_data.iloc[:, -1].to_numpy() - 1  # Subtract 1 from labels
sat_train_x, sat_val_x, sat_train_y, sat_val_y = train_test_split(sat_x, sat_y, test_size=0.2, random_state=42)
# Define CNN model for Fashion-MNIST
def create_cnn_fashion(learning_rate=0.01, momentum=0.9, l2_reg=0.01):
    model = Sequential([
        Conv2D(64, kernel_size=(3, 3), activation='relu', input_shape=(28, 28, 1), kernel_regularizer=l2(l2_reg)),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        Conv2D(128, (3, 3), activation='relu', kernel_regularizer=l2(l2_reg)),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        Conv2D(256, (3, 3), activation='relu', kernel_regularizer=l2(l2_reg)),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        Flatten(),
        Dense(128, activation='relu', kernel_regularizer=l2(l2_reg)),
        Dropout(0.5),
        Dense(10, activation='softmax')
    ])
    model.compile(optimizer=SGD(learning_rate=learning_rate, momentum=momentum), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.regularizers import l2

from keras.optimizers import Adam

#def create_cnn_6_classes(input_shape, learning_rate=0.01, momentum=0.9, l2_reg=0.01):
#    model = Sequential([
#        Conv1D(256, kernel_size=3, activation='relu', input_shape=input_shape, kernel_regularizer=l2(l2_reg)),
#        MaxPooling1D(pool_size=2),
#        Conv1D(512, kernel_size=3, activation='relu', kernel_regularizer=l2(l2_reg)),
#        MaxPooling1D(pool_size=2),
#        Conv1D(1024, kernel_size=3, activation='relu', kernel_regularizer=l2(l2_reg)),
#        MaxPooling1D(pool_size=2),
##        Conv1D(1024, kernel_size=3, activation='relu', kernel_regularizer=l2(l2_reg)),
#        MaxPooling1D(pool_size=2),
#        Flatten(),
#        Dense(512, activation='relu', kernel_regularizer=l2(l2_reg)),
#        Dropout(0.5),
#        Dense(6, activation='softmax')
#    ])
#    model.compile(optimizer=SGD(learning_rate=learning_rate, momentum=momentum), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
#    return model

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.regularizers import l2
from tensorflow.keras.optimizers import Adam
import tensorflow as tf

def create_cnn_6_classes(input_shape, learning_rate=0.001):
    model = Sequential([
        Conv1D(64, kernel_size=3, activation='relu', input_shape=input_shape),
        BatchNormalization(),
        MaxPooling1D(pool_size=2),
        
        Conv1D(128, kernel_size=3, activation='relu'),
        BatchNormalization(),
        MaxPooling1D(pool_size=2),
        
        Conv1D(256, kernel_size=3, activation='relu'),
        BatchNormalization(),
        MaxPooling1D(pool_size=2),
        
        Flatten(),
        Dense(512, activation='relu'),
        Dropout(0.4),  # You can adjust the dropout rate as needed
        
        Dense(6, activation='softmax')
    ])
    
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    
    return model


# Train and evaluate models
# Fashion MNIST
#fashion_model = create_cnn_fashion()
#fashion_model.fit(fashion_train_x, fashion_train_y, validation_data=(fashion_val_x, fashion_val_y), epochs=10, batch_size=50, verbose=1)
#fashion_val_predictions = fashion_model.predict(fashion_val_x)
#fashion_val_predicted_classes = np.argmax(fashion_val_predictions, axis=1)
#print("Fashion MNIST Classification Report:\n", classification_report(fashion_val_y, fashion_val_predicted_classes))
#print("Fashion MNIST Confusion Matrix:\n", confusion_matrix(fashion_val_y, fashion_val_predicted_classes))

# Blood Data
#blood_model = create_cnn_6_classes(blood_train_x[0].shape)
#blood_model.fit(blood_train_x, blood_train_y, validation_data=(blood_val_x, blood_val_y), epochs=10, batch_size=50, verbose=1)
#blood_val_predictions = blood_model.predict(blood_val_x)
#blood_val_predicted_classes = np.argmax(blood_val_predictions, axis=1)
#print("Blood Data Classification Report:\n", classification_report(blood_val_y, blood_val_predicted_classes))
#print("Blood Data Confusion Matrix:\n", confusion_matrix(blood_val_y, blood_val_predicted_classes))

# Satellite Data
sat_model = create_cnn_6_classes(sat_train_x[0].shape)
sat_model.fit(sat_train_x, sat_train_y, validation_data=(sat_val_x, sat_val_y), epochs=20, batch_size=50, verbose=1)
sat_val_predictions = sat_model.predict(sat_val_x)
sat_val_predicted_classes = np.argmax(sat_val_predictions, axis=1)
print("Satellite Data Classification Report:\n", classification_report(sat_val_y, sat_val_predicted_classes))
print("Satellite Data Confusion Matrix:\n", confusion_matrix(sat_val_y, sat_val_predicted_classes))
