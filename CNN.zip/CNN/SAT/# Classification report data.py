# Classification report data
fashion_mnist_classification_report = {
    "0": {"precision": 0.94, "recall": 0.96, "f1-score": 0.95, "support": 129},
    "1": {"precision": 1.00, "recall": 0.95, "f1-score": 0.97, "support": 138},
    "2": {"precision": 0.88, "recall": 0.88, "f1-score": 0.88, "support": 68},
    "3": {"precision": 0.79, "recall": 0.85, "f1-score": 0.82, "support": 67},
    "4": {"precision": 0.95, "recall": 0.89, "f1-score": 0.92, "support": 70},
    "5": {"precision": 0.79, "recall": 0.84, "f1-score": 0.82, "support": 69},
    "accuracy": 0.91,
    "macro avg": {"precision": 0.89, "recall": 0.89, "f1-score": 0.89, "support": 541},
    "weighted avg": {"precision": 0.91, "recall": 0.91, "f1-score": 0.91, "support": 541}
}

# Confusion matrix data as a list of lists
fashion_mnist_confusion_matrix = [
    [124, 0, 0, 2, 0, 3],
    [1, 131, 2, 1, 0, 3],
    [0, 0, 60, 4, 0, 4],
    [4, 0, 1, 57, 1, 4],
    [0, 0, 2, 5, 62, 1],
    [3, 0, 3, 3, 2, 58]
]

# Validation loss, training loss, and training accuracy data
fashion_mnist_val_loss= [
    1.3256, 1.1253, 1.1516, 0.8559, 0.7754, 0.6359, 0.5897, 0.4809, 0.5334, 0.3897,
    0.4069, 0.3563, 0.3577, 0.3491, 0.4739, 0.3645, 0.5698, 0.4661, 0.3915, 0.4000
]

fashion_mnist_loss = [
    1.1405, 0.6831, 0.6327, 0.4593, 0.4153, 0.3034, 0.2697, 0.2836, 0.2451, 0.2109,
    0.1885, 0.1987, 0.1625, 0.1120, 0.1328, 0.1480, 0.1002, 0.1862, 0.1180, 0.0848
]

fashion_mnist_val_accuracy = [
    0.4750, 0.5527, 0.5601, 0.6728, 0.7116, 0.7726, 0.7763, 0.8336, 0.8281, 0.8725,
    0.8632, 0.8872, 0.8891, 0.8983, 0.8632, 0.9020, 0.8688, 0.8817, 0.8965, 0.9094
]

fashion_mnist_accuracy = [
    0.6516, 0.7560, 0.8008, 0.8378, 0.8604, 0.8974, 0.9076, 0.9016, 0.9159, 0.9256,
    0.9307, 0.9321, 0.9409, 0.9630, 0.9487, 0.9519, 0.9635, 0.9399, 0.9612, 0.9737
]
# You can access individual metrics and values as before.

import matplotlib.pyplot as plt
import numpy as np

# Number of epochs
epochs = range(1, 21)

# Create subplots for loss and accuracy
plt.figure(figsize=(12, 6))

# Plot training and validation loss
plt.subplot(1, 2, 1)
plt.plot(epochs, fashion_mnist_loss, 'b-', label='Training Loss')
plt.plot(epochs, fashion_mnist_val_loss, 'r-', label='Validation Loss')
plt.title('Satelite Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# Plot training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(epochs, fashion_mnist_accuracy, 'b-', label='Training Accuracy')
plt.plot(epochs, fashion_mnist_val_accuracy, 'r-', label='Validation Accuracy')
plt.title('Satelite Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.tight_layout()

# Bar plot for F1-scores
f1_scores = [fashion_mnist_classification_report[str(i)]['f1-score'] for i in range(6)]
class_labels = ['Agua', 'Bosque','Ciudad', 'Cultivo','Desierto','Montana']

plt.figure(figsize=(8, 6))
plt.bar(class_labels, f1_scores, color='royalblue')
plt.title('Satelite F1-Scores')
plt.xlabel('Class Labels')
plt.ylabel('F1-Score')
plt.ylim([0, 1])
plt.xticks(rotation=45)
plt.show()


import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import confusion_matrix
import seaborn as sns

# Function to plot confusion matrix
def plot_confusion_matrix(cm, class_labels):
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_labels, yticklabels=class_labels)
    plt.title('Satelite Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()

# Function to plot classification report
def plot_classification_report(report):
    # Extract metrics and class labels
    metrics = ['precision', 'recall', 'f1-score', 'support']
    data = []
    for label, scores in report.items():
        if label.isdigit():
            data.append([float(scores[metric]) for metric in metrics])

    # Create an array to plot
    data_array = np.array(data)

    # Plot the classification report
    plt.figure(figsize=(10, 6))
    sns.heatmap(data_array, annot=True, cmap='Blues', xticklabels=metrics[:-1], yticklabels=class_labels)
    plt.title('Satelite Classification Report')
    plt.xlabel('Metrics')
    plt.ylabel('Class Labels')
    plt.show()

# Plot confusion matrix
confusion_matrix_data = np.array(fashion_mnist_confusion_matrix)
plot_confusion_matrix(confusion_matrix_data, class_labels)

# Plot classification report
plot_classification_report(fashion_mnist_classification_report)
