
# Loss and accuracy values for Fashion MNIST
fashion_mnist_loss =  [27.1935, 22.0832, 18.0318, 14.8039, 12.1929, 10.0570, 8.3198, 6.9146, 5.7624, 4.8027]
fashion_mnist_accuracy = [0.4313, 0.6990, 0.8053, 0.8622, 0.8829, 0.9041, 0.9120, 0.9161, 0.9145, 0.9207]

# Loss and accuracy values for validation set of Fashion MNIST
fashion_mnist_val_loss = [24.4056, 19.8147, 16.1716, 13.3897, 10.9823, 9.0769, 7.5424, 6.2410, 5.1915, 4.3667]
fashion_mnist_val_accuracy = [0.5340, 0.7711, 0.8823, 0.8408, 0.9071, 0.9121, 0.9187, 0.9237, 0.9337, 0.9254]

fashion_mnist_classification_report = {
    "0": {"precision": 0.89, "recall": 0.91, "f1-score": 0.90, "support": 91},
    "1": {"precision": 0.85, "recall": 0.96, "f1-score": 0.90, "support": 97},
    "2": {"precision": 0.99, "recall": 0.98, "f1-score": 0.98, "support": 98},
    "3": {"precision": 1.00, "recall": 0.84, "f1-score": 0.91, "support": 99},
    "4": {"precision": 0.90, "recall": 0.93, "f1-score": 0.91, "support": 97},
    "5": {"precision": 0.93, "recall": 0.93, "f1-score": 0.93, "support": 121},
    "accuracy": 0.93,
    "macro avg": {"precision": 0.93, "recall": 0.93, "f1-score": 0.92, "support": 603},
    "weighted avg": {"precision": 0.93, "recall": 0.93, "f1-score": 0.93, "support": 603}
}


fashion_mnist_confusion_matrix = [
 [83, 0, 0, 0, 5, 3],
 [0, 93, 1, 0, 0, 3],
 [0, 2, 96, 0, 0, 0],
 [1, 9, 0, 83, 4, 2],
 [6, 1, 0, 0, 90, 0],
 [3, 4, 0, 0, 1, 113]
]


import matplotlib.pyplot as plt
import numpy as np

# Number of epochs
epochs = range(1, 11)

# Create subplots for loss and accuracy
plt.figure(figsize=(12, 6))

# Plot training and validation loss
plt.subplot(1, 2, 1)
plt.plot(epochs, fashion_mnist_loss, 'b-', label='Training Loss')
plt.plot(epochs, fashion_mnist_val_loss, 'r-', label='Validation Loss')
plt.title('Blood Smear Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# Plot training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(epochs, fashion_mnist_accuracy, 'b-', label='Training Accuracy')
plt.plot(epochs, fashion_mnist_val_accuracy, 'r-', label='Validation Accuracy')
plt.title('Blood Smear Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.tight_layout()

# Bar plot for F1-scores
f1_scores = [fashion_mnist_classification_report[str(i)]['f1-score'] for i in range(6)]
class_labels =  [ "Basophils",  "Neutrophils",  "Eosinophils", "Erythroblasts",  "Lymphocytes", "Monocytes"]

plt.figure(figsize=(8, 6))
plt.bar(class_labels, f1_scores, color='royalblue')
plt.title('Blood Smear F1-Scores')
plt.xlabel('Class Labels')
plt.ylabel('F1-Score')
plt.ylim([0, 1])
plt.xticks(rotation=45)
plt.show()


import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import confusion_matrix
import seaborn as sns

# Function to plot confusion matrix
def plot_confusion_matrix(cm, class_labels):
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_labels, yticklabels=class_labels)
    plt.title('Blood Smear Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()

# Function to plot classification report
def plot_classification_report(report):
    # Extract metrics and class labels
    metrics = ['precision', 'recall', 'f1-score', 'support']
    data = []
    for label, scores in report.items():
        if label.isdigit():
            data.append([float(scores[metric]) for metric in metrics])


    # Create an array to plot
    data_array = np.array(data)

    # Plot the classification report
    plt.figure(figsize=(10, 6))
    sns.heatmap(data_array, annot=True, cmap='Blues', xticklabels=metrics[:-1], yticklabels=class_labels)
    plt.title('Blood Smear Classification Report')
    plt.xlabel('Metrics')
    plt.ylabel('Class Labels')
    plt.show()

# Plot confusion matrix
confusion_matrix_data = np.array(fashion_mnist_confusion_matrix)
plot_confusion_matrix(confusion_matrix_data, class_labels)

# Plot classification report
plot_classification_report(fashion_mnist_classification_report)
